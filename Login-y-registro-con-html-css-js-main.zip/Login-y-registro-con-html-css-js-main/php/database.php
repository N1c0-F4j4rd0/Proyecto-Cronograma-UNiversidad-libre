<?php
$host = "localhost";
$usuario = "root";
$password = "";
$db = "login_schedule";

$conexion = mysqli_connect($host, $usuario, $password, $db);

if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}
?>